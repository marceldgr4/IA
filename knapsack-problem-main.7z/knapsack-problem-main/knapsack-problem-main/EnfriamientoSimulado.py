import numpy as np
import matplotlib.pyplot as plt
import time
import pandas as pd

from helpers import print_results

# archivo
data = pd.read_excel('Mochila_capacidad_maxima_10kg.xlsx')
values = data['Valor'].tolist()
weights = data['Peso_kg'].tolist()
item_limits = data['Cantidad'].tolist()
capacity = 10
n_items = len(weights)


# Define the simulated annealing function
def simulated_annealing(weights, values, capacity, n_items, t_init=20, t_min=0.01, alpha=0.99, n_iter=1000):
    # Initialize the current state
    cur_state = np.zeros(n_items, dtype=int)

    # Define the objective function
    def objective(state):
        # Calculate the total weight and value of the state
        total_weight = np.sum(weights * state)
        total_value = np.sum(values * state)

        # Return 0 if the state violates the capacity constraint
        if total_weight > capacity or any(state[i] > item_limits[i] for i in range(n_items)):
            return 0

        # Return the total value of the state
        return total_value, total_weight

    # Initialize the best state
    best_state = cur_state.copy()
    best_obj, best_weight = objective(cur_state)
    obj_vals = [best_obj]

    # Initialize the temperature
    t = t_init

    # Iterate until convergence
    start = time.time()
    iter_convergence = -1
    for i in range(n_iter):
        # Generate a new state by randomly flipping one item
        new_state = cur_state.copy()
        idx = np.random.randint(n_items)
        if new_state[idx] < item_limits[idx]:  # Check if item limit not exceeded
            new_state[idx] += 1
        else:
            continue
        while np.sum(weights * new_state) > capacity:
            # Find a non-zero item index at random and decrement its count
            non_zero_indices = np.where(new_state > 0)[0]
            remove_idx = np.random.choice(non_zero_indices)
            new_state[remove_idx] -= 1

        # Calculate the objective function of the new state
        new_obj, new_weight = objective(new_state)

        # Calculate the acceptance probability
        delta = new_obj - best_obj
        if delta > 0:
            accept_prob = 1
        else:
            accept_prob = np.exp(delta / t)

        # Accept or reject the new state
        if np.random.rand() < accept_prob:
            cur_state = new_state
            cur_obj = new_obj
            if new_obj > best_obj:
                best_state = new_state
                best_obj = new_obj
                best_weight = new_weight
                obj_vals.append(best_obj)
        else:
            obj_vals.append(best_obj)

        # Update the temperature
        t *= alpha
        if t < t_min:
            break
        elif iter_convergence == -1 and best_obj > 0:
            if np.abs(obj_vals[-2] - best_obj) < 1e-9:
                iter_convergence = i

    # Return the best state and its objective value
    return best_state, best_obj, best_weight, obj_vals, time.time() - start, iter_convergence


df = []
# Run the simulated annealing algorithm
for i in range(30):
    best_state, best_obj, best_weight, obj_vals, crono, iter_convergence = simulated_annealing(
        weights,
        values,
        capacity,
        n_items,
        t_init=400,
        t_min=0.02,
        alpha=0.99,
        n_iter=1000
    )
    print_results(best_state, best_weight, best_obj, iter_convergence, crono)

    # Plot the convergence graph
    plt.plot(obj_vals)
    plt.xlabel('Iterations')
    plt.title(f'Intento N°{i+1}')
    plt.show()
    df.append([best_obj, best_weight, iter_convergence, crono, best_state])
    

resultados_df = pd.DataFrame(df, columns=['Price', 'Weight', 'Convergence iteration', 'Execution Time', 'Solution'])
resultados_df.to_csv("simulated_annealing_algorithm_results_enfriami.csv", index=True)