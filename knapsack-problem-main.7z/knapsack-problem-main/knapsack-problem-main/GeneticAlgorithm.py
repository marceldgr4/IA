import random
import time

import matplotlib.pyplot as plt
import pandas as pd

from helpers import extract_data_from_file, format_solution


class GeneticAlgorithm:
    def __init__(
        self,
        items_quantity,
        population_quantity,
        n_generations,
        max_weight,
        weights,
        prices,
        crossover_rate=0.9,
        mutation_rate=0.05
    ):
        self.items_quantity = items_quantity
        self.population_quantity = population_quantity
        self.n_generations = n_generations
        self.max_weight = max_weight
        self.weights = weights
        self.prices = prices
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.fitnesses = []

    @staticmethod
    def generate_random_value():
        return random.randint(0, 1)

    def create_individual(self):
        return [self.generate_random_value() for _ in range(self.items_quantity)]

    def compute_weight(self, individual):
        sum_weight = sum(c * x for c, x in zip(individual, self.weights))
        return sum_weight

    def compute_fitness(self, individual):
        fitness = sum(c * x for c, x in zip(individual, self.prices))

        if self.compute_weight(individual) > self.max_weight:
            fitness = 0
        return fitness

    def selection(self, sorted_population):
        index1 = random.randint(0, self.population_quantity - 1)
        while True:
            index2 = random.randint(0, self.population_quantity - 1)
            if index2 != index1:
                break
        individual = sorted_population[index1]

        if index1 < index2:
            individual = sorted_population[index2]

        return individual

    def crossover(self, individual1, individual2):
        individual_c1 = individual1.copy()
        individual_c2 = individual2.copy()
        if random.random() < self.crossover_rate:
            index = random.randint(1, self.items_quantity - 2)
            for i in range(index):
                individual_c1[i] = individual2[i]
                individual_c2[i] = individual1[i]
        return individual_c1, individual_c2

    def mutate(self, individual):
        individual_new = individual.copy()
        if random.random() < self.mutation_rate:
            index = random.randint(0, self.items_quantity - 1)
            individual_new[index] = self.generate_random_value()
        return individual_new

    def create_new_population(self, old_population):
        sorted_old_population = sorted(old_population, key=self.compute_fitness)
        self.fitnesses.append(self.compute_fitness(sorted_old_population[-1]))

        new_population = []
        while len(new_population) < self.population_quantity - 2:
            individual1 = self.selection(sorted_old_population)
            individual2 = self.selection(sorted_old_population)

            individual_c1, individual_c2 = self.crossover(individual1, individual2)

            individual_m1 = self.mutate(individual_c1)
            individual_m2 = self.mutate(individual_c2)

            new_population.append(individual_m1)
            new_population.append(individual_m2)

        new_population.append(sorted_old_population[-1])
        new_population.append(sorted_old_population[-2])

        return new_population

    def run(self, elements_id, show_convergence_chart=True, display_info=True):
        start_time = time.time()
        population = [self.create_individual() for _ in range(self.population_quantity)]
        best_population = None
        best_fitness = None
        best_generation = None

        for i in range(self.n_generations):
            population = self.create_new_population(population)
            sorted_population = sorted(population, key=self.compute_fitness)
            current_best = sorted_population[-1]
            current_best_fitness = self.compute_fitness(current_best)

            if best_fitness is None or current_best_fitness > best_fitness:
                best_population = current_best
                best_fitness = current_best_fitness
                best_generation = i

        end_time = time.time()
        time_to_find_solution = end_time - start_time

        if display_info:
            self.display_solution_info(elements_id, best_population, best_fitness, best_generation, time_to_find_solution)

        if show_convergence_chart:
            self.show_convergence_chart()

        return (
            format_solution(elements_id, best_population),
            self.compute_weight(best_population),
            best_fitness,
            best_generation,
            time_to_find_solution
        )

    def display_solution_info(self, elements_id, best_population, best_fitness, best_generation, time_to_find_solution):
        print('Best solution: ', format_solution(elements_id, best_population))
        print('Weight: ', self.compute_weight(best_population))
        print('Value: ', best_fitness)
        print('Found at generation: ', best_generation)
        print("%.4f Secs" % time_to_find_solution)

    def show_convergence_chart(self):
        plt.plot(self.fitnesses)
        plt.xlabel('Generations')
        plt.ylabel('Fitness')
        plt.title('Convergence chart')
        plt.show()


if __name__ == '__main__':
    items_weight, items_price, items_id = extract_data_from_file()
    result_data = []
    for _ in range(30):
        algorithm = GeneticAlgorithm(
            items_quantity=len(items_id),
            population_quantity=100,
            n_generations=120,
            max_weight=10,
            weights=items_weight,
            prices=items_price,
            crossover_rate=0.99,
            mutation_rate=0.03
        )
        _, weight, price, found_at_generation, execution_time = algorithm.run(items_id, True, True)
        result_data.append([
            price,
            weight,
            found_at_generation,
            execution_time
        ])
    df = pd.DataFrame(data=result_data, columns=['Price', 'Weight', 'Convergence iteration', 'Execution Time'])
    now = time.strftime("%Y-%m-%d_%H-%M-%S")
    df.to_csv(f'genetic_algorithm_results_genetico{now}.csv', index=False)


