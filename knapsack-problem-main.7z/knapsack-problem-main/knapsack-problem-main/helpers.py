import matplotlib.pyplot as plt
import pandas as pd


def extract_data_from_file():
    data = pd.read_excel('Mochila_capacidad_maxima_10kg.xlsx')
    values = data['Valor'].tolist()
    weights = data['Peso_kg'].tolist()
    item_limits = data['Cantidad'].tolist()
    ids = data['Id']
    items = len(values)

    final_weights = []
    final_values = []
    final_ids = []

    for i in range(items):
        amount = item_limits[i]
        for _ in range(amount):
            final_weights.append(weights[i])
            final_values.append(values[i])
            final_ids.append(ids[i])

    return final_weights, final_values, final_ids


def format_solution(input_ids, solution):
    final_solution = {}

    for i in range(len(solution)):
        if input_ids[i] not in final_solution:
            final_solution[input_ids[i]] = 0

        if solution[i] == 1:
            final_solution[input_ids[i]] += 1

    return list(final_solution.values())


def print_results(solution, weight, price, convergence_iteration, execution_time):
    print('Best solution: ', solution)
    print('Weight: ', weight)
    print('Price: ', price)
    print('Found at generation:', convergence_iteration)
    print("Execution time: %.4f Secs" % execution_time)
    print('\n')


def generate_convergence_graph(solution_price, title="Iteration"):
    plt.plot(solution_price)
    plt.xlabel(title)
    plt.ylabel('Price')
    plt.title('Convergence chart')
    plt.show()
