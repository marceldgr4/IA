import random
import pandas as pd
import time
import matplotlib.pyplot as plt


df = []
def ant_colony_optimization(max_iterations, num_ants, pheromone_constant, evaporation_rate, capacity, weights, values, verbose=True, iter=0):
    # Initialize pheromone levels
    num_items = len(weights)
    pheromones = [pheromone_constant] * num_items
    best_solution = None
    best_value = 0
    best_iter = 0

    # Create convergence graph lists
    convergence_x = []
    convergence_y = []

    # Initialize previous best value to 0
    prev_best_value = 0

    # Run the algorithm for the specified number of iterations
    start = time.time()
    for i in range(max_iterations):
        # Initialize ants
        ant_solutions = []
        for ant in range(num_ants):
            ant_solution = [0] * num_items
            ant_weight = 0
            ant_value = 0

            # Build the ant's solution
            while ant_weight < capacity:
                # Choose the next item to add to the solution
                item = roulette_wheel_selection(pheromones, ant_solution, weights, item_limits, capacity - ant_weight)
                if item is None:
                    break

                # Add the item to the solution
                ant_solution[item] += 1
                ant_weight += weights[item]
                ant_value += values[item]

                # Check if the item's limit has been reached
                if ant_solution[item] >= item_limits[item]:
                    break

            # Save the ant's solution
            ant_solutions.append((ant_solution, ant_value))

            # Update the global best solution if necessary
            if ant_value > best_value:
                best_solution = ant_solution
                best_value = ant_value
                best_iter = i

        # Update pheromone levels
        for j in range(num_items):
            for ant_solution, ant_value in ant_solutions:
                pheromones[j] += ant_solution[j] * (ant_value / capacity)
            pheromones[j] *= evaporation_rate

        # Add best value to convergence graph
        convergence_x.append(i)
        convergence_y.append(best_value)

        # Check if the algorithm has converged to a new best solution
        if best_value != prev_best_value:
            print(f"Iteration {i}: New best value = {best_value}")
            prev_best_value = best_value
            best_iter = i

        # Print progress
        if verbose and i % (max_iterations // 10) == 0:
            print(f"Iteration {i}: Best value = {best_value}")

    # Plot convergence graph
    plt.plot(convergence_x, convergence_y)
    aux = best_value
    timer = time.time() - start
    df.append((aux, timer, best_iter))
    plt.title(f"Convergence {iter}")
    plt.xlabel("Iteration")
    plt.ylabel("Best value")
    plt.show()

    return best_solution, best_value, timer, best_iter


def roulette_wheel_selection(pheromones, solution, weights, item_limits, remaining_capacity):
    total_pheromone = 0
    for i in range(len(pheromones)):
        if solution[i] < item_limits[i] and weights[i] <= remaining_capacity:
            total_pheromone += pheromones[i]

    if total_pheromone == 0:
        return None

    target = random.uniform(0, total_pheromone)
    cum_pheromone = 0
    for i in range(len(pheromones)):
        if solution[i] < item_limits[i] and weights[i] <= remaining_capacity:
            cum_pheromone += pheromones[i]
            if cum_pheromone >= target:
                return i

    return None


# parametros
max_iterations = 400 # numero de iteraciones
num_ants = 20 # tamaño de la colonia
pheromone_constant = 4
evaporation_rate = 0.2


# archivo
data = pd.read_excel('Mochila_capacidad_maxima_10kg.xlsx')
values = data['Valor'].tolist()
weights = data['Peso_kg'].tolist()
item_limits = data['Cantidad'].tolist()
capacity = 10


for i in range(30):
    best_solution, best_value, crono, best_iter = ant_colony_optimization(max_iterations, num_ants, pheromone_constant,
                                                               evaporation_rate, capacity, weights, values, iter=i + 1)
    print("Best solution:", best_solution)
    print("Iterations to converge:", best_iter)
    print("Best value:", best_value)
    print(f"Total time: {crono} s")

aux_df = pd.DataFrame(df)
aux_df = pd.DataFrame(df)
now = time.strftime("%Y-%m-%d_%H-%M-%S")
aux_df.to_csv(f"resultados_ConoliaHormiga_{now}.csv")

